export const routes = [
    { path: "/", name: "Home" },
    { path: "/clinician", name: "Clinician" },
    { path: "/patient", name: "Patient" },
];

export default routes;