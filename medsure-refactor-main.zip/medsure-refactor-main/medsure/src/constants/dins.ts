export const dins = [
    {
      path: "/din",
      name: "Indian Act Registration Number",
    },
    {
      path: "/din",
      name: "First Nations Client ID Number (B-Number)",
    },
    {
      path: "/din",
      name: "Intuit Client ID Number (N-Number)",
    },
    {
      path: "/na",
      name: "Govt. of NWT Health Plan Number",
    },
    {
      path: "/na",
      name: "Govt. of Nunavut Health Plan Number",
    },
  ];
  
export default dins;