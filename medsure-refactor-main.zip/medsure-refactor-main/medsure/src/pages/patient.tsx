import React from "react";
import Link from "next/link";
import dins from "@/constants/dins";

const buttonStyle = "text-green-500 border-green-500 border-2 p-2 rounded-lg my-2 transition-colors hover:bg-green-500 hover:text-white";

const Patient = () => {
  return (
    <div className="din-scanner h-screen bg-orange-300 flex justify-center items-center">
      <div className="viewfinder">
        <h1 className="viewfinder-text text-green-500">Do you have one of the following?</h1>
        <div className="flex flex-col items-center mt-4 space-y-4">
          {dins.map((din) => (
            <div key={din.name}>
              <Link href={din.path}>
                <button className={buttonStyle}>{din.name}</button>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Patient;