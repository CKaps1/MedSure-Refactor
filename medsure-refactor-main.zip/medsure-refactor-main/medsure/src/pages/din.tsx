import React, { useState } from 'react';
import CameraCapture from '@/components/cameracapture';
import Link from 'next/link';

const buttonStyle = "text-white bg-green-500 border-green-500 border-2 p-2 rounded-lg my-2 transition-colors hover:bg-green-700";

const Din: React.FC = () => {
  const [profileData, setProfileData] = useState(null);

  return (
    <div className="din-scanner h-screen bg-orange-300 flex justify-center items-center">
      <div className="viewfinder border-2 border-green-500 rounded-lg w-72 h-48 flex items-center justify-center">
        <div className="viewfinder-text text-green-500 text-center">
          Place DIN/NPN/PDIN
          <br />
          within viewfinder
        </div>
      </div>
      <Link href="/covered" className={buttonStyle}>
          Verify
      </Link>
      <CameraCapture />
    </div>
  );
};

export default Din;