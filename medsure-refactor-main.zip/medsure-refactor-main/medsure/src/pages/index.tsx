import Head from "next/head";
import Link from "next/link";
import Navbar from "@/components/navbar"

export default function Home() {
  return (
    <div>
      <Navbar />
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">
            Are you a clinician or a patient?
          </h1>
          <div className="space-x-4">
            <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
              <a href="/clinician">Clinician</a>
            </button>
            <button className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
              <a href="/patient">Patient</a>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
