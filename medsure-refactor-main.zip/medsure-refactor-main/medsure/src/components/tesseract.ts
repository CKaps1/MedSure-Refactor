import Tesseract from 'tesseract.js';

export async function recognizeTextFromImage(imageUrl: any): Promise<any> {
  const worker = await Tesseract.createWorker();
  await worker.loadLanguage('eng');
  await worker.initialize('eng');
  //const { data: { text } } = await worker.recognize(imageUrl);
  const res = await worker.recognize(imageUrl);
  await worker.terminate();
  //return text;
  return res;
}
