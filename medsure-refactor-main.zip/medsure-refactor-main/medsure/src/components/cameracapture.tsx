import React, { useRef, useState, useEffect } from 'react';
import axios from 'axios';
import { recognizeTextFromImage } from '@/components/tesseract';
import Tesseract from 'tesseract.js';

const CameraCapture: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState<boolean>(false);

  // idk what this does, im tired
  const dataURLToText = (dataURL) => {
    return new Promise((resolve, reject) => {
      const dataURIParts = dataURL.split(',');
      if (dataURIParts.length !== 2) {
        reject(new Error('Invalid data URL format'));
        return;
      }
  
      const mimeType = dataURIParts[0].match(/:(.*?);/)[1];
      const imageData = atob(dataURIParts[1]);
      const dataArray = new Uint8Array(imageData.length);
      for (let i = 0; i < imageData.length; i++) {
        dataArray[i] = imageData.charCodeAt(i);
      }
  
      const imageBlob = new Blob([dataArray], { type: mimeType });
      const image = new Image();
      image.src = URL.createObjectURL(imageBlob);
      
      image.onload = () => {
        Tesseract.recognize(
          image,
          'eng', 
          {
            logger: info => console.log(info), 
          }
        ).then(result => {
          resolve(result.data.text);
        }).catch(error => {
          reject(error);
        });
      };
    });
  }

  const handleCameraToggle = async () => {
    try {
      if (!isCameraOpen) {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
        setIsCameraOpen(true);
      }
      else {
        if (isCameraOpen && videoRef.current) {
            const canvas = document.createElement('canvas');
            canvas.width = videoRef.current.videoWidth;
            canvas.height = videoRef.current.videoHeight;
            const ctx = canvas.getContext('2d');
            if (ctx) {
                ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
                const dataUrl = canvas.toDataURL('image/jpeg');
                setCapturedImage(dataUrl);
                const imgElement = document.createElement('img');
                imgElement.src = dataUrl;
                imgElement.className = 'w-full h-auto'; // Apply Tailwind CSS classes for image sizing
                const divContainer = document.getElementById('viewfinder-text');
                if (divContainer) {
                    divContainer.innerHTML = '';
                    divContainer.appendChild(imgElement);
                }
                // Run Tesseract OCR on the captured image
                //const recognizedText = await recognizeTextFromImage(dataUrl);

                // Display the recognized text in the console
                //alert('Tesseract Recognized Text:', recognizedText);

                const regex = /^data:image\/jpeg;base64,(.*)$/;
                const match = dataUrl.match(regex);

                if (match && match[1]) {
                    const base64Data = match[1];
                    console.log(base64Data);
                    let imageBuffer = Buffer.from(base64Data, "base64");

                    try {
                        const recognizedText = await recognizeTextFromImage(imageBuffer);
                        console.log('Tesseract Recognized Text:', recognizedText);
                    } catch (error) {
                        console.error('Error recognizing text:', error);
                    }
                } else {
                    console.error('Invalid data URL or format');
                }

                setCapturedImage(dataUrl);
                alert(dataUrl);
            }
      }
    } 
  }
    catch (error) {
      console.error('Error accessing camera:', error);
    }
  };

  /*
  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isCameraOpen]);
  */

  return (
    <div>
      <video ref={videoRef} className={`w-64 h-48 ${isCameraOpen ? 'block' : 'hidden'}`} />
      <button onClick={handleCameraToggle} className="text-white bg-blue-500 px-4 py-2 rounded-lg">
        {isCameraOpen ? 'Capture Image' : 'Open Camera'}
      </button>
      {capturedImage && <img src={capturedImage} alt="Captured" className="mt-4" />}
    </div>
  );
};

export default CameraCapture;